import React, { useState } from 'react';
import axios from 'axios';
import './DomainChecker.css';

function DomainChecker() {
  const [domain, setDomain] = useState('');
  const [selectedTaskType, setSelectedTaskType] = useState('');
  const [showAgentForm, setShowAgentForm] = useState(false);
  const [agentData, setAgentData] = useState({
    name: '',
    description: '',
    email: ''
  });
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);

  const API_URL = 'http://localhost:8000/api';

  const domainsData = [
    { name: 'yandex.ru', time: '0.09 мс', status: 'ok' },
    { name: 'vk.com', time: '0.1 мс', status: 'ok' },
    { name: 'ok.com', time: '10 мс', status: 'bad' },
    { name: 'tremolino.ru', time: '0.019 мс', status: 'ok' },
    { name: 'auto.ru', time: '>99 мс', status: 'bad' }
  ];

  const taskTypes = [
    { value: 'ping', label: 'PING' },
    { value: 'dns', label: 'DNS' },
    { value: 'http', label: 'HTTP' },
    { value: 'traceroute', label: 'TRACEROUTE' },
    { value: 'tcp', label: 'TCP' },
    { value: 'full', label: 'FULL' }
  ];

  const handleCheck = async (e) => {
    e.preventDefault();
    if (!domain.trim() || !selectedTaskType) return;

    setLoading(true);
    setResults(null);
    
    try {
      const data = { 
        target: domain, 
        type: selectedTaskType 
      };

      console.log('📤 Отправляем запрос:', data);

      // 1. Создаем задачу
      const taskRes = await axios.post(`${API_URL}/checks`, data);
      console.log('✅ Задача создана:', taskRes.data);
      
      const taskId = taskRes.data.id;

      // 2. Ожидаем результат
      let finalResult;
      for (let attempt = 0; attempt < 30; attempt++) {
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        const resultRes = await axios.get(`${API_URL}/checks/${taskId}`);
        finalResult = resultRes.data;
        
        console.log(`🔄 Попытка ${attempt + 1}:`, finalResult.status);

        if (finalResult.status !== 'pending' && finalResult.status !== 'queued') {
          console.log('🎉 Check completed!');
          break;
        }
        
        if (attempt === 29) {
          console.log('⏰ Timeout reached');
        }
      }

      console.log('📊 Финальный результат:', finalResult);
      setResults(finalResult);
      
    } catch (error) {
      console.log('❌ Ошибка:', error);
      alert(`Ошибка: ${error.response?.data?.detail || error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleTaskTypeSelect = (type) => {
    setSelectedTaskType(type);
  };

  const handleAgentFormToggle = () => {
    setShowAgentForm(!showAgentForm);
    if (showAgentForm) {
      setAgentData({ name: '', description: '', email: '' });
    }
  };

  const handleAgentInputChange = (e) => {
    const { name, value } = e.target;
    setAgentData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleAgentSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`${API_URL}/agents/register`, agentData);
      console.log('✅ Агент создан:', response.data);
      setShowAgentForm(false);
      setAgentData({ name: '', description: '', email: '' });
      alert('Агент успешно создан! API ключ отправлен на почту.');
    } catch (error) {
      console.log('❌ Ошибка создания агента:', error);
      alert('Ошибка при создании агента');
    }
  };

  const isAgentFormValid = agentData.name.trim() && 
                          agentData.description.trim() && 
                          agentData.email.trim();

  return (
    <div className="domain-checker">
      {/* Статус-карточки */}
      <div className="status-bar">
        {domainsData.map((item, index) => (
          <div key={index} className={`status-card ${item.status}`}>
            <div className="domain">{item.name}</div>
            <div className="info-row">
              <span className="ping">{item.time}</span>
              <span className={`status ${item.status}`}>
                {item.status === 'ok' ? 'OK' : 'BAD'}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Поле ввода */}
      <div className="input-container">
        <div className="input-label">Домен или IP</div>
        <input
          type="text"
          className="domain-input"
          placeholder="Введите адрес..."
          value={domain}
          onChange={(e) => setDomain(e.target.value)}
        />
      </div>

      {/* Кнопки действий */}
      <div className="action-buttons">
        <div 
          className="action-button"
          onClick={() => document.getElementById('task-modal').style.display = 'flex'}
        >
          {selectedTaskType ? taskTypes.find(t => t.value === selectedTaskType)?.label : 'Выберите тип проверки'}
        </div>
        <div 
          className={`action-button ${loading ? 'loading' : ''}`}
          onClick={handleCheck}
          disabled={loading || !domain || !selectedTaskType}
        >
          {loading ? '⏳ Проверка...' : 'Проверить'}
        </div>
      </div>

      {/* Результаты */}
      {results && (
        <div className="results-container">
          <h3>📊 Результаты проверки:</h3>
          <div className="results-content">
            <pre>{JSON.stringify(results, null, 2)}</pre>
          </div>
        </div>
      )}

      {/* Форма добавления агента */}
      <div className={`agent-form-container ${showAgentForm ? 'expanded' : ''}`}>
        <div className="agent-form-content">
          {showAgentForm ? (
            <form className="agent-form" onSubmit={handleAgentSubmit}>
              <div className="form-row">
                <input
                  type="text"
                  name="name"
                  placeholder="Имя агента"
                  value={agentData.name}
                  onChange={handleAgentInputChange}
                  className="form-input"
                />
              </div>
              <div className="form-row">
                <input
                  type="text"
                  name="description"
                  placeholder="Описание"
                  value={agentData.description}
                  onChange={handleAgentInputChange}
                  className="form-input"
                />
              </div>
              <div className="form-row">
                <input
                  type="email"
                  name="email"
                  placeholder="Ваша почта"
                  value={agentData.email}
                  onChange={handleAgentInputChange}
                  className="form-input"
                />
              </div>
              <div className="form-buttons">
                <button 
                  type="submit" 
                  className={`submit-agent-btn ${isAgentFormValid ? 'active' : ''}`}
                  disabled={!isAgentFormValid}
                >
                  Создать
                </button>
                <button 
                  type="button" 
                  className="cancel-agent-btn"
                  onClick={handleAgentFormToggle}
                >
                  Отмена
                </button>
              </div>
            </form>
          ) : (
            <div 
              className="add-agent-toggle"
              onClick={handleAgentFormToggle}
            >
              Добавить агента
            </div>
          )}
        </div>
      </div>

      {/* Модальное окно выбора типа проверки */}
      <div id="task-modal" className="modal">
        <div className="modal-content">
          <h3 className="modal-title">Выберите тип проверки</h3>
          <div className="task-types-grid">
            {taskTypes.map((type) => (
              <div
                key={type.value}
                className={`task-type ${selectedTaskType === type.value ? 'selected' : ''}`}
                onClick={() => {
                  handleTaskTypeSelect(type.value);
                  document.getElementById('task-modal').style.display = 'none';
                }}
              >
                {type.label}
              </div>
            ))}
          </div>
          <button 
            className="modal-close"
            onClick={() => document.getElementById('task-modal').style.display = 'none'}
          >
            Закрыть
          </button>
        </div>
      </div>
    </div>
  );
}

export default DomainChecker;